"""Let Python know that the `tests/` folder is a package for Test Discovery [1].

[1]: https://docs.python.org/3/library/unittest.html#unittest-test-discovery
"""
